# Codable-and-JSON
Example of Codable protocol and parsing JSON in Swift using JSONDecoder.
