//
//  ImageAssetsApp.swift
//  ImageAssets
//
//  Created by Kaden Marshall on 9/24/23.
//

import SwiftUI

@main
struct ImageAssetsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
