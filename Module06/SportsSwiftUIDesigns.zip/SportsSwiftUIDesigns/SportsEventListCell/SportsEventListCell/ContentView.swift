//
//  ContentView.swift
//  SportsEventListCell
//
//  Created by Kaden Marshall on 9/25/23.
//

import SwiftUI

//struct ContentView: View{
//    let event = eventsList
//}

//import SwiftUI
//
//struct ContentView: View {
//    let events = eventList
//    var body: some View {
//        NavigationView {
//            List {
//                ForEach(events, id: \.self) {event in NaviagationLink(destination: Text(event)) {
//                    Image("baseball","basketball")
//                    Text(event)
//                }}
//            }
//        }
//    }
//}
//
//#Preview {
//    ContentView()
//}
struct SportsEventListView: View {
    var body:  some View {
            List{
                Text("Portland at Orlando")
                Image("basketball");Text("hi")
                Text("Charlotte at Detroit")
                Text("Edmonton at Washington")
                Text("Baltimore at Cincinati")
                Text("Tenenesee at Missouri")
                Text("Houston at Tennesee")
                Text("Nationals at Dodgers")
                Text("Cubs at Giant")
                Text("Ny Rangers at Toronto")
                Text("Calgary at Tampa")
            
            }
        }

            
        }
struct SportsEventListView_Preview: PreviewProvider {
    static var previews: some View {
        SportsEventListView()
    }
}
