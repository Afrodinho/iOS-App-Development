//
//  Games.swift
//  SportsEventListCell
//
//  Created by Kaden Marshall on 9/29/23.
//

import Foundation

let eventList = [
    "Portland at Orlando",
    "Charlotte at Detroit",
     "Edmonton at Washington",
     "Baltimore at Cincinati",
     "Tenenesee at Missouri",
     "Houston at Tennesee",
     "Nationals at Dodgers",
     "Cubs at Giant",
    "Ny Rangers at Toronto",
     "Calgary at Tampa",

]
