//
//  SportsEventListCellApp.swift
//  SportsEventListCell
//
//  Created by Kaden Marshall on 9/29/23.
//

import SwiftUI

@main
struct SportsEventListCellApp: App {
    var body: some Scene {
        WindowGroup {
            SportsEventListView()
        }
    }
}
