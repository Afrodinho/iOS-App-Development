//
//  AppleiPhoneChooseApp.swift
//  AppleiPhoneChoose
//
//  Created by Kaden Marshall on 10/13/23.
//

import SwiftUI

@main
struct AppleiPhoneChooseApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
