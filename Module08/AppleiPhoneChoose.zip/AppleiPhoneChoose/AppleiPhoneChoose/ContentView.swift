//
//  ContentView.swift
//  AppleiPhoneChoose
//
//  Created by Kaden Marshall on 10/13/23.
//

import SwiftUI

//gray background: Color(.sRGB, red: 0.953, green: 0.953, blue: 0.969, opacity: 1.0)
//
//sierra blue:  Color(.sRGB, red: 0.694, green: 0.776, blue: 0.851, opacity: 1.0)
//
//silver: Color(.sRGB, red: 0.953, green: 0.957, blue: 0.941, opacity: 1.0)
//
//gold: Color(.sRGB, red: 0.969, green: 0.925, blue: 0.843, opacity: 1.0)
//
//graphite: Color(.sRGB, red: 0.376, green: 0.365, blue: 0.357, opacity: 1.0)



struct ContentView: View {
    var body: some View {
        VStack {
            Text("From $999 or 41.62/mo before tradein")
        }
        //box:Sierra Blue
        VStack() {
            VStack(alignment: .leading){
                VStack(alignment: .leading){
                    Text("Choose Finish").bold()
                }
                HStack{
                    //why is my rectangle not changing colors
                    RoundedRectangle(cornerRadius: 25.0)
                        .stroke(style: /*@START_MENU_TOKEN@*/StrokeStyle()/*@END_MENU_TOKEN@*/)
                        .background(Color.white)
                        .frame(width: 175, height: 150)
                        .overlay(
                            VStack{
                                Circle()
                                    .strokeBorder(Color.gray,lineWidth: 1.0)
                                //Find Sierra Blue color
                                    .background(Circle().foregroundColor(Color(.sRGB, red: 0.694, green: 0.776, blue: 0.851, opacity: 1.0)))
                                    .frame(width: 35, height: 35)
                                Text("Sierra Blue")
                                    .foregroundColor(.black)
                            }
                        )
                    RoundedRectangle(cornerRadius: 25.0)
                        .stroke(style: /*@START_MENU_TOKEN@*/StrokeStyle()/*@END_MENU_TOKEN@*/)
                        .background(Color.white)
                        .frame(width: 175, height: 150)
                        .overlay(
                            VStack{
                                Circle()
                                    .strokeBorder(Color.gray,lineWidth: 1.0)
                                    .background(Circle().foregroundColor(.gray))
                                //Find Silver color
                                    .frame(width: 35, height: 35)
                                Text("Silver")
                                    .foregroundColor(.black)
                            }
                        )
                }
                //g0ld
                HStack{
                    RoundedRectangle(cornerRadius: 25.0)
                        .stroke(style: /*@START_MENU_TOKEN@*/StrokeStyle()/*@END_MENU_TOKEN@*/)
                        .background(Color.white)
                        .frame(width: 175, height: 150)
                        .overlay(
                            VStack{
                                Circle()
                                    .strokeBorder(Color.gray,lineWidth: 1.0)
                                    .background(Circle().foregroundColor(.yellow))
                                //Find Silver color
                                    .frame(width: 35, height: 35)
                                Text("Gold")
                                    .foregroundColor(.black)
                            }
                        )
                    HStack{
                        RoundedRectangle(cornerRadius: 25.0)
                            .stroke(style: /*@START_MENU_TOKEN@*/StrokeStyle()/*@END_MENU_TOKEN@*/)
                            .background(Color.white)
                            .frame(width: 175, height: 150)
                            .overlay(
                                VStack{
                                    Circle()
                                        .strokeBorder(Color.gray,lineWidth: 1.0)
                                        .background(Circle().foregroundColor(.black))
                                    //Find graphite color
                                        .frame(width: 35, height: 35)
                                    Text("Graphite")
                                        .foregroundColor(.black)
                                }
                                
                            )
                    }
                }
                
                
                
                //Data sizes
                
    
                HStack{
                RoundedRectangle(cornerRadius: 25.0)
                    .stroke(style: /*@START_MENU_TOKEN@*/StrokeStyle()/*@END_MENU_TOKEN@*/)
                    .background(Color.white)
                    .frame(width: 175, height: 150)
                    .overlay(
                        VStack{
                            Text("128GB")
                                .foregroundColor(.black)
                            Text("From $999 or 41.62/mo. before trade-in*")
                        }
                        )
                RoundedRectangle(cornerRadius: 25.0)
                    .stroke(style: /*@START_MENU_TOKEN@*/StrokeStyle()/*@END_MENU_TOKEN@*/)
                    .background(Color.white)
                    .frame(width: 175, height: 150)
                    .overlay(
                        VStack{
                            Text("256GB")
                                .foregroundColor(.black)
                            Text("From $1099 or 45.79/mo. before trade-in*")
                        }
                        )
                        }
                HStack{
                    RoundedRectangle(cornerRadius: 25.0)
                        .stroke(style: /*@START_MENU_TOKEN@*/StrokeStyle()/*@END_MENU_TOKEN@*/)
                        .background(Color.white)
                        .frame(width: 175, height: 150)
                        .overlay(
                            VStack{
                                Text("128GB")
                                    .foregroundColor(.black)
                                Text("From $1299 or 54.12/mo. before trade-in*")
                            }
                        )
                    RoundedRectangle(cornerRadius: 25.0)
                        .stroke(style: /*@START_MENU_TOKEN@*/StrokeStyle()/*@END_MENU_TOKEN@*/)
                        .background(Color.white)
                        .frame(width: 175, height: 150)
                        .overlay(
                            VStack{
                                Text("1TB")
                                    .foregroundColor(.black)
                                Text("From $1499 or 62.45/mo. before trade-in*")
                                
                            }
                        )
                }
            }
        }}
}

#Preview {
    ContentView()
}
