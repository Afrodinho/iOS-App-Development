//
//  ContentViewApp.swift
//  ContentView
//
//  Created by Kaden Marshall on 8/28/23.
//

import SwiftUI

@main
struct ContentViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
