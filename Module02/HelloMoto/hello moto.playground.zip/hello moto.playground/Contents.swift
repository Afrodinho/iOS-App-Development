import UIKit

for index in stride(from:5, through: 1, by: -1){
    print(index,"\n")
}
var greeting = "hello moto"
print(greeting)
