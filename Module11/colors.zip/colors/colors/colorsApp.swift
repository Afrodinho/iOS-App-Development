//
//  colorsApp.swift
//  colors
//
//  Created by Kaden Marshall on 11/1/23.
//

import SwiftUI

@main
struct colorsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
