//
//  ContentView.swift
//  colors
//
//  Created by Kaden Marshall on 11/1/23.
//

import SwiftUI

struct ContentView: View{
    @State private var bgColor =
        Color(.sRGB, red: 0.98, green: 0.9, blue: 0.2)
   

    var body: some View {
        VStack {
            ColorPicker("Selected Color:", selection: $bgColor)
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
            .fill(bgColor)
            .frame(width:150, height:150)
            .padding()
    }
}

#Preview {
    ContentView()
}
