//
//  gameLeadersApp.swift
//  gameLeaders
//
//  Created by Kaden Marshall on 10/6/23.
//

import SwiftUI

@main
struct gameLeadersApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
