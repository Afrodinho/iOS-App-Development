//
//  ContentView.swift
//  gameLeaders
//
//  Created by Kaden Marshall on 10/4/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        //Top
        VStack {
            HStack{
                Text("Game Leaders")
            }
            //QB
            VStack{
                Divider()
                    .frame(width:350)
                Text("Passing Yards")
                Divider()
                HStack{
                    VStack{
                        Image("H Hooker")
                            .resizable()
                            .frame(width: 90, height:90, alignment: .leading)
                            .clipShape(Circle())
                        Text("TENN")
                    }
                    VStack(alignment: .trailing){
                        Text("H. Hooker")
                        Text("15-19")
                        Text("80 YDS, 3 INT")
                    }
                    Divider().frame(height: 90)
                    HStack(alignment: .top){
                    }
                    VStack(alignment: .center){
                        Text("C. Bazelak")
                        Text("18-26")
                        Text("206 YDS, 2 TD, 1 INT")
                    }
                    VStack(alignment: .trailing){
                        Image("C Bazelak")
                            .resizable()
                            .frame(width: 90, height:90, alignment: .trailing)
                            .clipShape(Circle())
                        Text("MIZ")
                    }
                }
                //END OF QB
                
                //RB
                VStack{
                    Divider()
                        .frame(width:350)
                    Text("Rushing Yards")
                    Divider()
                    HStack{
                        VStack{
                            Image("T Evans")
                                .resizable()
                                .frame(width: 90, height:90, alignment: .leading)
                                .clipShape(Circle())
                            Text("TENN")
                        }
                        VStack(alignment: .trailing){
                            Text("T. Evans")
                            Text("15 CAR")
                            Text("150 YDS, 2 TD")
                        }
                        Divider().frame(height: 90)
                        HStack(alignment: .top){
                        }
                        VStack(alignment: .center){
                            Text("T. Badie")
                            Text("23 CAR")
                            Text("437 YDS, 4 TD")
                        }
                        VStack(alignment: .trailing){
                            Image("T Badie")
                                .resizable()
                                .frame(width: 90, height:90, alignment: .trailing)
                                .clipShape(Circle())
                            Text("MIZ")
                        }
                        
                    }
                }
                //END RUSHING
                
                //Receptions
                
                VStack{
                    Divider()
                        .frame(width:350)
                    Text("Recieving Yards")
                    Divider()
                    HStack{
                        VStack{
                            Image("V Jones Jr")
                                .resizable()
                                .frame(width: 90, height:90, alignment: .leading)
                                .clipShape(Circle())
                            Text("TENN")
                        }
                        VStack(alignment: .trailing){
                            Text("V. Jones Jr.")
                            Text("15 CAR")
                            Text("150 YDS, 2 TD")
                        }
                        Divider().frame(height: 90)
                        HStack(alignment: .top){
                        }
                        VStack(alignment: .center){
                            Text("K. Chism")
                            Text("23 CAR")
                            Text("437 YDS, 2 TD")
                        }
                        VStack(alignment: .trailing){
                            Image("K Chism")
                                .resizable()
                                .frame(width: 90, height:90, alignment: .trailing)
                                .clipShape(Circle())
                            Text("MIZ")
                        }
                        
                    }
                }
                
            
                
                
            }
            }
            }
//        VStack(alignment: .center, spacing: 0) {
//            Image("C Bazelak").clipShape(Circle()) 
//            Image("H Hooker").clipShape(Circle())
//            Image("T Evans").clipShape(Circle())
//        }
    }


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
