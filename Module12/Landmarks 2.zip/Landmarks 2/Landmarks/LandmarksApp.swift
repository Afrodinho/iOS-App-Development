//
//  LandmarksApp.swift
//  Landmarks
//
//  Created by Kaden Marshall on 11/10/23.
//

import SwiftUI

@main
struct LandmarksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
