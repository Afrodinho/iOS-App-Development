//
//  ComposeInterfaceApp.swift
//  ComposeInterface
//
//  Created by Kaden Marshall on 11/10/23.
//

import SwiftUI

@main
struct ComposeInterfaceApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
