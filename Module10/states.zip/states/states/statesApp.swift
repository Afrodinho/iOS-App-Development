//
//  statesApp.swift
//  states
//
//  Created by Kaden Marshall on 10/27/23.
//

import SwiftUI

@main
struct statesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
